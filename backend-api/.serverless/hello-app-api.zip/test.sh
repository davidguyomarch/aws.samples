#!/bin/bash

serverless invoke local --function hello --path ./hello.js
